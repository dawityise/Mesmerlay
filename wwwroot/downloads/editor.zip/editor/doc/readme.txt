/**********************************************************************
	Version: FreeRichTextEditor.com Version 1.00.
	License: http://creativecommons.org/licenses/by/2.5/
	Description: Readme File.
	Author: Copyright (C) 2006  Steven Ewing
**********************************************************************/
	Hi, thanks for downloading FreeRTE
	This is the first non beta release of FreeRichTextEditor, 
	Please send any bug reports, feedback, questions to steve@freerichtexteditor.com

	For examples on how to implement FreeRTE look in the examples directory.

	You are free to use this editor as you wish as long as all copyright notices remain intact.
	
	You are free to redistribute this zip file as you wish as long as the contents remain unmodified.

	Please refer to http://creativecommons.org/licenses/by/2.5/ for other license conditions.

	If you wish to remove the copyrights from FreeRTE please refer to this link
	http://www.freerichtexteditor.com/page/5.htm

	Any other donations are welcome also
	http://www.freerichtexteditor.com/page/7.htm

	Author: Steven Ewing
	Email: steve@freerichtexteditor.com
	Homepage: http://www.freerichtexteditor.com
	Additional Credits: Ron Callaghan, Jacob Lee