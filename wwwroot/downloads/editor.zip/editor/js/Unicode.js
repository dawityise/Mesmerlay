﻿var letter;
var objEvent;
var isBackSpace = false;
$(document.getElementById('freeRTE').contentWindow.document).keydown(function(objEvent) {
    objEvent ? keycode = objEvent.which : keycode = event.keyCode;
    var store = document.getElementById('hdn');
    var fidel = document.getElementById("fidel");
    if (keycode == 8) {
        if (fidel.innerHTML !="") {
            fidel.innerHTML = ""; store.value = ""; return false;
        }
        else { store.value = ""; }
    }
});

$(document.getElementById('freeRTE').contentWindow.document).keypress(function(objEvent) {
    objEvent ? keycode = objEvent.which : keycode = event.keyCode;
    letter = String.fromCharCode(keycode);
    var store = document.getElementById('hdn');
    var input = document.getElementById('freeRTE');
    var fidel = document.getElementById("fidel");
    var word;
    //alert(keycode);

    if (keycode != 32) {
        store.value = store.value + letter;
    }
    else {
        store.value = "";
        if (fidel.innerHTML != null) {
            rteInsertHTML(fidel.innerHTML); fidel.innerHTML = "";
        }
    }
    if (keycode == 13) {
        store.value = "";
        if (fidel.innerHTML != null) {
            rteInsertHTML(fidel.innerHTML);
            fidel.innerHTML = "";
        }
    }

    word = store.value;

    if (word.length > 0) {

        var num = "";
        var uni = "";
        if (word.length == 3) {
            num = checkThree(word);
            uni = '"\\u' + num + '"';
            //if word has no meaning e.g. "tab" "mos" "tae"
            if (num == "") {
                //e.g word "sea" if "tae" t-ae ? ta-e
                var thirdChar = word.charAt(2);
                var firstChar = word.charAt(0);
                var firstTwo = word.charAt(0) + word.charAt(1);
                var lastTwo = word.charAt(1) + word.charAt(2);
                var tirgum;
                if (thirdChar == "a" || thirdChar == "e" || thirdChar == "i" || thirdChar == "o" || thirdChar == "u") {
                    tirgum = checkOne(thirdChar);
                    if (tirgum == "") {
                        tirgum = checkOne(firstChar);
                        if (/^[A-F\d]{4}$/.test(tirgum)) {
                            uni = '"\\u' + tirgum + '"';
                            rteInsertHTML(eval(uni));

                            store.value = lastTwo;
                            tirgum = checkTwo(lastTwo);

                            if (/^[A-F\d]{4}$/.test(tirgum)) {
                                uni = '"\\u' + tirgum + '"';
                                fidel.innerHTML = eval(uni);
                            }

                        }

                    }
                    else {
                        tirgum = checkTwo(word.substring(0, 2));
                        if (/^[A-F\d]{4}$/.test(tirgum)) {
                            uni = '"\\u' + tirgum + '"';
                            rteInsertHTML(eval(uni));
                        }
                        store.value = word.charAt(2);
                        tirgum = checkOne(word.charAt(2));
                        if (/^[A-F\d]{4}$/.test(tirgum)) {
                            uni = '"\\u' + tirgum + '"';
                            fidel.innerHTML = eval(uni);
                        }
                    }

                }
                else {
                    tirgum = checkTwo(word.substring(0, 2));
                    if (/^[A-F\d]{4}$/.test(tirgum)) {
                        uni = '"\\u' + tirgum + '"';
                        rteInsertHTML(eval(uni));
                    }
                    store.value = word.charAt(2);
                    tirgum = checkOne(word.charAt(2));
                    if (/^[A-F\d]{4}$/.test(tirgum)) {
                        uni = '"\\u' + tirgum + '"';
                        fidel.innerHTML = eval(uni);
                    }
                    else {
                        fidel.innerHTML = "";
                        store.value = "";
                    }
                }
            }
            else {
                if (/^[A-F\d]{4}$/.test(num)) {
                    uni = '"\\u' + num + '"';
                    rteInsertHTML(eval(uni));
                    store.value = "";
                    fidel.innerHTML = "";
                }
            }

        }
        else if (word.length == 2) {
            num = checkTwo(word);
            //if word is like "hh" function returns ""
            if (num == "") {
                var tirgum;
                store.value = word.charAt(1);
                tirgum = checkOne(word.charAt(1));

                if (/^[A-F\d]{4}$/.test(tirgum)) {
                    uni = '"\\u' + tirgum + '"';
                    fidel.innerHTML = eval(uni);

                }
                else {
                    fidel.innerHTML = "";
                    store.value = "";
                }
                tirgum = checkOne(word.charAt(0));

                if (/^[A-F\d]{4}$/.test(tirgum)) {
                    uni = '"\\u' + tirgum + '"';
                    rteInsertHTML(eval(uni));

                }

            } else {
                tirgum = checkTwo(word);
                lastChar = word.charAt(1);
                if (/^[A-F\d]{4}$/.test(tirgum)) {

                    uni = '"\\u' + tirgum + '"';
                    if (lastChar == "a" || lastChar == "e" || lastChar == ("u")) {
                        fidel.innerHTML = eval(uni);
                    } else { rteInsertHTML(eval(uni)); store.value = ""; fidel.innerHTML = ""; }

                }

            }

        }
        else {
            tirgum = checkOne(word);
            if (/^[A-F\d]{4}$/.test(tirgum)) {
                uni = '"\\u' + tirgum + '"';
                fidel.innerHTML = eval(uni);

            }
        }


    }

    //ignore english characters ":", ";", ",", "#"
    if (keycode == 58 || keycode == 59 || keycode == 44 || keycode == 35 || keycode == 126) {
        return false;
    }
    if (keycode > 64 && keycode < 123
        && keycode != 91 && keycode != 92
        && keycode != 93 && keycode != 94
        && keycode != 95 && keycode != 96) {

        return false;
    }

});


function checkOne(str) {
    switch (str) {
        case "a":
            num = "12A5";
            break;
        case "A":
            num = "12D5";
            break;
        case "b":
            num = "1265";
            break;
        case "c":
            num = "127D";
            break;
        case "C":
            num = "132D";
            break;
        case "d":
            num = "12F5";
            break;
        case "f":
            num = "134D"
            break;
        case "g":
            num = "130D"
            break;
        case "h":
            num = "1205"
            break;
        case "H":
            num = "1215"
            break;        
        case "j":
            num = "1305"
            break;
        case "k":
            num = "12AD"
            break;
        case "l":
            num = "120D"
            break;
        case "m":
            num = "121D"
            break;
        case "n":
            num = "1295"
            break;
        case "N":
            num = "129D"
            break;
        
        case "p":
            num = "1355"
            break;
        case "P":
            num = "1335"
            break;
        case "q":
            num = "1245"
            break;
        case "r":
            num = "122D"
            break;
        case "s":
            num = "1235"
            break;
        case "S":
            num = "1225"
            break;
        case "t":
            num = "1275"
            break;
        case "v":
            num = "126D"
            break;
        case "w":
            num = "12CD"
            break;
        case "x":
            num = "123D"
            break;
        case "y":
            num = "12ED"
            break;
        case "z":
            num = "12DD"
            break;
        case "Z":
            num = "12E5"
            break;
        case "T":
            num = "1325"
            break;
        case "~":
            num = "1345"
            break;
        case "#":
            num = "133D"
            break;
        case ":":
            num = "1361"
            break;
        case ",":
            num = "1363"
            break;
        case ";":
            num = "1364"
            break;    
        default:
            num = "";
            break;
    }
    return num;
}

function checkTwo(str) {
    switch (str) {
        //a
        case "ae":
            num = "12A0"
            break;
        case "au":
            num = "12A1"
            break;
        case "ai":
            num = "12A2"
            break;
        case "ao":
            num = "12A6"
            break;
        //A 
        case "Ae":
            num = "12D0"
            break;
        case "Au":
            num = "12D1"
            break;
        case "Ai":
            num = "12D2"
            break;
        case "Ao":
            num = "12D6"
            break;
        
        //b 
        case "be":
            num = "1260"
            break;
        case "bu":
            num = "1261"
            break;
        case "bi":
            num = "1262"
            break;
        case "ba":
            num = "1263"
            break;
        case "bo":
            num = "1266"
            break;
        //c 
        case "ce":
            num = "1278"
            break;
        case "cu":
            num = "1279"
            break;
        case "ci":
            num = "127A"
            break;
        case "ca":
            num = "127B"
            break;
        case "co":
            num = "127E"
            break;

        //C  
        case "Ce":
            num = "1328"
            break;
        case "Cu":
            num = "1329"
            break;
        case "Ci":
            num = "132A"
            break;
        case "Ca":
            num = "132B"
            break;
        case "Co":
            num = "132E"
            break;

        //d  
        case "de":
            num = "12F0"
            break;
        case "du":
            num = "12F1"
            break;
        case "di":
            num = "12F2"
            break;
        case "da":
            num = "12F3"
            break;
        case "do":
            num = "12F6"
            break;
        //f   
        case "fe":
            num = "1348"
            break;
        case "fu":
            num = "1349"
            break;
        case "fi":
            num = "134A"
            break;
        case "fa":
            num = "134B"
            break;
        case "fo":
            num = "134E"
            break;
        //g   
        case "ge":
            num = "1308"
            break;
        case "gu":
            num = "1309"
            break;
        case "gi":
            num = "130A"
            break;
        case "ga":
            num = "130B"
            break;
        case "go":
            num = "130E"
            break;
        //h 
        case "he":
            num = "1200"
            break;
        case "hu":
            num = "1201"
            break;
        case "hi":
            num = "1202"
            break;
        case "ha":
            num = "1203"
            break;
        case "ho":
            num = "1206"
            break;
        //H 
        case "He":
            num = "1210"
            break;
        case "Hu":
            num = "1211"
            break;
        case "Hi":
            num = "1212"
            break;
        case "Ha":
            num = "1213"
            break;
        case "Ho":
            num = "1216"
            break;

        //j   
        case "je":
            num = "1300"
            break;
        case "ju":
            num = "1301"
            break;
        case "ji":
            num = "1302"
            break;
        case "ja":
            num = "1303"
            break;
        case "jo":
            num = "1306"
            break;

        //k    
        case "ke":
            num = "12A8"
            break;
        case "ku":
            num = "12A9"
            break;
        case "ki":
            num = "12AA"
            break;
        case "ka":
            num = "12AB"
            break;
        case "ko":
            num = "12AE"
            break;
        //l    
        case "le":
            num = "1208"
            break;
        case "lu":
            num = "1209"
            break;
        case "li":
            num = "120A"
            break;
        case "la":
            num = "120B"
            break;
        case "lo":
            num = "120E"
            break;
        //m    
        case "me":
            num = "1218"
            break;
        case "mu":
            num = "1219"
            break;
        case "mi":
            num = "121A"
            break;
        case "ma":
            num = "121B"
            break;
        case "mo":
            num = "121E"
            break;

        //n    
        case "ne":
            num = "1290"
            break;
        case "nu":
            num = "1291"
            break;
        case "ni":
            num = "1292"
            break;
        case "na":
            num = "1293"
            break;
        case "no":
            num = "1296"
            break;
        //N     
        case "Ne":
            num = "1298"
            break;
        case "Nu":
            num = "1299"
            break;
        case "Ni":
            num = "129A"
            break;
        case "Na":
            num = "129B"
            break;
        case "No":
            num = "129E"
            break;
        //p    
        case "pe":
            num = "1350"
            break;
        case "pu":
            num = "1351"
            break;
        case "pi":
            num = "1352"
            break;
        case "pa":
            num = "1353"
            break;
        case "po":
            num = "1356"
            break;
        //P     
        case "Pe":
            num = "1330"
            break;
        case "Pu":
            num = "1331"
            break;
        case "Pi":
            num = "1332"
            break;
        case "Pa":
            num = "1333"
            break;
        case "Po":
            num = "1336"
            break;
        //q    
        case "qe":
            num = "1240"
            break;
        case "qu":
            num = "1241"
            break;
        case "qi":
            num = "1242"
            break;
        case "qa":
            num = "1243"
            break;
        case "qo":
            num = "1246"
            break;

        //r    
        case "re":
            num = "1228"
            break;
        case "ru":
            num = "1229"
            break;
        case "ri":
            num = "122A"
            break;
        case "ra":
            num = "122B"
            break;
        case "ro":
            num = "122E"
            break;

        //s    
        case "se":
            num = "1230"
            break;
        case "su":
            num = "1231"
            break;
        case "si":
            num = "1232"
            break;
        case "sa":
            num = "1233"
            break;
        case "so":
            num = "1236"
            break;
        //S     
        case "Se":
            num = "1220"
            break;
        case "Su":
            num = "1221"
            break;
        case "Si":
            num = "1222"
            break;
        case "Sa":
            num = "1223"
            break;
        case "So":
            num = "1226"
            break;

        //t    
        case "te":
            num = "1270"
            break;
        case "tu":
            num = "1271"
            break;
        case "ti":
            num = "1272"
            break;
        case "ta":
            num = "1273"
            break;
        case "to":
            num = "1276"
            break;

        //T     
        case "Te":
            num = "1320"
            break;
        case "Tu":
            num = "1321"
            break;
        case "Ti":
            num = "1322"
            break;
        case "Ta":
            num = "1323"
            break;
        case "To":
            num = "1326"
            break;

        //v    
        case "ve":
            num = "1268"
            break;
        case "vu":
            num = "1269"
            break;
        case "vi":
            num = "126A"
            break;
        case "va":
            num = "126B"
            break;
        case "vo":
            num = "126E"
            break;

        //w    
        case "we":
            num = "12C8"
            break;
        case "wu":
            num = "12C9"
            break;
        case "wi":
            num = "12CA"
            break;
        case "wa":
            num = "12CB"
            break;
        case "wo":
            num = "12CE"
            break;

        //x    
        case "xe":
            num = "1238"
            break;
        case "xu":
            num = "1239"
            break;
        case "xi":
            num = "123A"
            break;
        case "xa":
            num = "123B"
            break;
        case "xo":
            num = "123E"
            break;

        //y    
        case "ye":
            num = "12E8"
            break;
        case "yu":
            num = "12E9"
            break;
        case "yi":
            num = "12EA"
            break;
        case "ya":
            num = "12EB"
            break;
        case "yo":
            num = "12EE"
            break;

        //z    
        case "ze":
            num = "12D8"
            break;
        case "zu":
            num = "12D9"
            break;
        case "zi":
            num = "12DA"
            break;
        case "za":
            num = "12DB"
            break;
        case "zo":
            num = "12DE"
            break;

        //Z     
        case "Ze":
            num = "12E0"
            break;
        case "Zu":
            num = "12E1"
            break;
        case "Zi":
            num = "12E2"
            break;
        case "Za":
            num = "12E3"
            break;
        case "Zo":
            num = "12E6"
            break;

        //# == ts      
        case "~e":
            num = "1340"
            break;
        case "~u":
            num = "1341"
            break;
        case "~i":
            num = "1342"
            break;
        case "~a":
            num = "1343"
            break;
        case "~o":
            num = "1346"
            break;
        
        //# == Ts       
        case "#e":
            num = "1338"
            break;
        case "#u":
            num = "1339"
            break;
        case "#i":
            num = "133A"
            break;
        case "#a":
            num = "133B"
            break;
        case "#o":
            num = "133E"
            break;


        default:
            num = "";
            break;
    }
    return num;
}

function checkThree(str) {
    switch (str) {
        case "aee":
            num = "12A4"
            break;
        case "Aee":
            num = "12D4"
            break;
        case "hee":
            num = "1204"
            break;
        case "Hee":
            num = "1214"
            break;
        case "lee":
            num = "120C"
            break;
        case "mee":
            num = "121C"
            break;
        case "see":
            num = "1234"
            break;
        case "See":
            num = "1224"
            break;
        case "ree":
            num = "122C"
            break;
        case "xee":
            num = "123C"
            break;
        case "qee":
            num = "1244"
            break;
        case "bee":
            num = "1264"
            break;
        case "vee":
            num = "126C"
            break;
        case "tee":
            num = "1274"
            break;
        case "Tee":
            num = "1324"
            break;
        case "cee":
            num = "127C"
            break;
        case "Cee":
            num = "132C"
            break;
        case "nee":
            num = "1294"
            break;
        case "Nee":
            num = "129C"
            break;
        case "kee":
            num = "12AC"
            break;
        case "wee":
            num = "12CC"
            break;
        case "zee":
            num = "12DC"
            break;
        case "Zee":
            num = "12E4"
            break;
        case "yee":
            num = "12EC"
            break;
        case "dee":
            num = "12F4"
            break;
        case "jee":
            num = "1304"
            break;
        case "gee":
            num = "130C"
            break;
        case "fee":
            num = "134C"
            break;
        case "pee":
            num = "1354"
            break;
        case "Pee":
            num = "1334"
            break;
        case "~ee":
            num = "1344"
            break;        
        case "#ee":
            num = "133C"
            break;
        case "Hua":
            num = "1217"
            break;
        case "lua":
            num = "120F"
            break;
        case "rua":
            num = "122F"
            break;
        case "xua":
            num = "123F"
            break;
        case "Sua":
            num = "1227"
            break;
        case "sua":
            num = "1237"
            break;
        case "bua":
            num = "1267"
            break;
        case "vua":
            num = "126F"
            break;
        case "cua":
            num = "127F"
            break;
        case "hua":
            num = "128B"
            break;
        case "nua":
            num = "1297"
            break;
        case "Nua":
            num = "129F"
            break;
        case "Zua":
            num = "12E7"
            break;
        case "zua":
            num = "12DF"
            break;
        case "dua":
            num = "12F7"
            break;
        case "jua":
            num = "1307"
            break;
        case "Cua":
            num = "132F"
            break;
        case "fua":
            num = "134F"
            break;
        case "Pua":
            num = "1337"
            break;
        case "pua":
            num = "1357"
            break;
        case "#ua":
            num = "133F"
            break;
        case "tua":
            num = "1277"
            break;
        case "kua":
            num = "12AF"
            break;
        case "qua":
            num = "124B"
            break;
        case "gua":
            num = "130F"
            break;
        case "mua":
            num = "121F"
            break;
        case "Tua":
            num = "1327"
            break;        
        default:
            num = "";
            break;
    }
    return num;
}

